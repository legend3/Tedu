package org.legend.dao;

public interface IStudentDao {
    String queryStudentbyId();
}
