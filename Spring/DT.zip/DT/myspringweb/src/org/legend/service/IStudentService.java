package org.legend.service;

public interface IStudentService {
    String queryStudentById();
}
