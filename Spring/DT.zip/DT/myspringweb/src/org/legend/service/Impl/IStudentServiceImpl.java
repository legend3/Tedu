package org.legend.service.Impl;

import org.legend.dao.IStudentDao;
import org.legend.dao.Impl.StudentDaoImpl;
import org.legend.service.IStudentService;

public class IStudentServiceImpl implements IStudentService {
    IStudentDao studentDao = new StudentDaoImpl();
    @Override
    public String queryStudentById() {
        return studentDao.queryStudentbyId();
    }
}
