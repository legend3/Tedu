# 利用Spring框架进行开发至少需要5+1个jar
### spring-aop
### spring-context
### spring-core
### spring-beans
### spring-expression
### commons-logging
### spring-web
