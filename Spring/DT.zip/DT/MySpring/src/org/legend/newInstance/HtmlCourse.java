package org.legend.newInstance;

public class HtmlCourse implements ICourse {
    @Override
    public void learn() {
        System.out.println("学习Html..");
    }
}
