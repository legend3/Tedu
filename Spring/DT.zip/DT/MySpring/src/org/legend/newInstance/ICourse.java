package org.legend.newInstance;
//课程
public interface ICourse {
    void learn();//学习...
}
