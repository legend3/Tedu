package org.legend.newInstance;

public class JavaCourse implements ICourse{
    @Override
    public void learn() {
        System.out.println("学习Java....");
    }
}
