package org.legend.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.stereotype.Component;

@Component("logAround")
public class LogAround implements MethodInterceptor {
    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        Object result = null;
        try{
            //方法体1
            System.out.println("环绕-前置通知...");
            //方法体2
            result = invocation.proceed();//是否执行点(目标方法)
            //方法3
            System.out.println("环绕-后置通知...");
            System.out.println("目标对象：" + invocation.getThis() + "\n目标方法：" + invocation.getMethod() +
                    "\n目标方法参数的个数：" + invocation.getArguments().length
                    + "\n目标方法的返回值：" + result);//此时的result还是与addStudent(Student student)一致！
        }catch (Exception e) {
            System.out.println("环绕-异常通知");
        }
        return "abc";//影响(原始的-logAfter)后置通知
    }
}
