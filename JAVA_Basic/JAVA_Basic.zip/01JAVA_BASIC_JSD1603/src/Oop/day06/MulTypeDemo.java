package Oop.day06;

//多态的演示
public class MulTypeDemo {
	public static void main(String[] args) {
		Aoo o1 = new Boo(); //向上造型(自动类型转换)
		System.out.println("创建出的o1:" + o1);
		System.out.println(o1.getClass());//输出所属类
		Boo o2 = (Boo) o1; //Boo对象实例(o1)在o2的变量的引用下，恢复真身，可以使用全部功能了<将其对象类型还原！>
							//o1引用类型的真实身份就是Boo类型！
		System.out.println("o2:" + o2);
		if(o1 instanceof Aoo){//判断引用指向的对象是否是某种类型
			System.out.println("True");
		}
		if(o1 instanceof Boo){
			System.out.println("True");
		}

		Inter1 o3 = (Inter1)o1; //引用所指向对象Boo实现了Inter1接口

		try {
			Coo o4 = (Coo)o1; //类型转换异常
			if(o1 instanceof Coo){
				Coo o5 = (Coo)o1;
			}
		}catch (ClassCastException c){
			System.out.println("强转的引用指向对象不是此类型:" + c);
		}
	}

}

interface Inter1{
}

class Aoo{
}

class Boo extends Aoo implements Inter1{
}

class Coo extends Aoo{
}















