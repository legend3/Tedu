package Oop.day06;
//匿名内部类的演示
public class NstInnerClassDemo {

	public static void main(String[] args) {
		//1.创建了Inter2的子类，没有名字
		//2.为该子类创建了一个对象，叫o1
		//3.大括号中的为子类的类体
		Inter2 o1 = new Inter2(){
		};
		
		//1.创建了Inter2的子类，没有名字
		//2.为该子类创建了一个对象，叫o2
		//3.大括号中的为子类的类体
		new Inter2(){
			public void hi(){
				System.out.println("匿名内部类");
			}
		};

//		final int num = 5;
		int num = 5;

		//1.创建Inter3的一个子类，没有名字
		//2.为该子类创建了一个对象，名为o3
		//3.大括号中的为子类的类体
		Inter3 o3 = new Inter3(){
			public void show(){
				System.out.println("showshow");
//				num = 6;
				System.out.println(num);//Java 8更加智能：如果局部变量被匿名内部类访问，那么该局部变量相当于自动使用了final修饰。
			}
		};
		o3.show();
	}
}

interface Inter3{
	void show();
}

interface Inter2{
	
}
