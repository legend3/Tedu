package Basic.day02;
//变量的演示
public class VarDemo {
	public static void main(String[] args) {
		/*
		 * 变量的练习:
		 * 1.声明一个整型变量，名为a
		 *   声明三个整型变量，名为b,c,d
		 * 2.声明整型变量e并直接赋值为250
		 *   声明整型变量f，
		 *     给变量f赋值为250
		 * 3.声明整型变量g并赋值为25.67----???
		 *   声明整型变量h并赋值为5
		 *     声明整型变量i并赋值为h+10，输出i的值
		 *   在h本身基础之上增10，输出h的值
		 *   输出m的值------------???
		 *   声明整型变量m，输出m的值-------???
		 * 4.声明几个正确的和几个错误的变量名
		 */
		

		//4.变量的命名:
//		int a1,a_,a_5$;
//		//int a*b; //编译错误，不能包含*号
//		//int 1a; //编译错误，不能以数字开头
//		int m=5;
//		System.out.println(M); //编译错误，严格区分大小写
//		int class; //编译错误，不能使用关键字
//		int 年龄; //正确，但不建议
//		int age; //建议"见名知意"
//		int score,myScore,myJavaScore; //建议"驼峰命名法"

		//3.变量的使用
//		//int a=3.14159; //编译错误，数据类型不匹配
//		int a=5; //声明整型变量a并赋值为5
//		int b=a+10; //取出a的值5，加10后，再赋值给b
//		System.out.println(b); //输出b的值15
//		a=a+10; //取出a的值5，加10后，再赋值给a
//		        //在a本身基础之上增10
//		System.out.println(a); //输出a的值15

		//System.out.println(m); //编译错误，m未声明
//		int m;
		//System.out.println(m); //编译错误，m未初始化


		//2.变量的初始化:第一次赋值
//		int a=250; //声明整型变量a并赋值为250
//		int b; //声明整型变量b
//		b=250; //给b赋值为250
//		System.out.println("a:" + a + "\nb:" + b);


		 //1.变量的声明
//		int a; //声明一个整型变量名为a
//		int b,c,d; //声明三个整型变量，名为b,c,
////		System.out.println("a:" + a);//无法打印
	}
}
