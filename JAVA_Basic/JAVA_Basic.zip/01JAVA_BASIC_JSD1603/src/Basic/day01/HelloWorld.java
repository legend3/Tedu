package Basic.day01;

/**
 * HelloWorld
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("HelloWorld!");
        System.out.println("今天天气真好！心情也好！");
    }
}
