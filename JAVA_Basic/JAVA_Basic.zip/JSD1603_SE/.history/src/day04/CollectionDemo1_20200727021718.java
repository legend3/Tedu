

/*
 * @Author: LEGEND
 * @since: 2020-02-19 02:34:54
 * @lastTime: 2020-07-27 02:17:18
 * @LastAuthor: Do not edit
 * @FilePath: \JSD1603_SE\src\day04\CollectionDemo1.java
 * @Description: 
 * @version: 
 */ 


package day04;


import java.util.*;


/**
 * boolean remove(E e)
 * 删除集合中给定的元素，成功删除返回true
 * @author Administrator
 *
 */
public class CollectionDemo1 {
	public static void main(String[] args) {
		Collection c = new ArrayList();

		c.add(new Point(1,2));
		c.add(new Point(3,4));
		c.add(new Point(5,6));
		c.add(new Point(1,2));
		System.out.println(c);
		Point p = new Point(1,2);
		/*
		 * remove方法删除元素也是依靠元素自身
		 * equals比较的结果。
		 * remove会将给定元素依次与集合中每个元素
		 * 进行比较，然后删除第一个与给定元素equals
		 * 比较为true的元素后停止删除。
		 */
		System.out.println(c.contains(p));//false,因为p只是引用地址，集合存储的是元素的引用地址
		c.remove(p);
		System.out.println("删除完毕");
		System.out.println(c);
	}
}
