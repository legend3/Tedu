package day08;

public class Demo02 {

	public static void main(String[] args) {
		int i=0;
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
		System.out.println(i++ & 0x7);
	}

}
