package day08;

public class Demo01 {

	public static void main(String[] args) {
		//int i = -20;
		//System.out.println(
		//	Integer.toBinaryString(i)); 
		for(int i=0; i>=-20; i--){
			System.out.println(
				Integer.toBinaryString(i));
		}
	}

}
