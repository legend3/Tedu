package day02;
/**
 * 要求在控制台输入一个计算表达式:
 * 例如:
 * 1+2  
 * 3
 * 
 * a+1
 * 不是数学计算表达式
 * 
 * 1.2+1.2
 *
 * @author Administrator
 *
 */
public class Work01 {

}
