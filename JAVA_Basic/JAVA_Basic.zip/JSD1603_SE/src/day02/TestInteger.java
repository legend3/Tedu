package day02;

public class TestInteger {
	public static void main(String[] args) {
		String str = "";
		dosome(str);
		
		Point p = new Point();
		dosome(p);
		
		int i = 1;
		Integer in = new Integer(i);
		dosome(in);
	
		int d = in.intValue();
	}
	
	public static void dosome(Object obj){
		
	}
}
