package day10;

public class MyThread extends Thread{
	@Override
		public void run() {
		System.out.println("Hello World!");
	}
}
