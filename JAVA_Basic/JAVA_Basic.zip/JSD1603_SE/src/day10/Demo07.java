package day10;

public class Demo07 {

	public static void main(String[] args) {
	}
	
	public void login(String name, String pwd) throws NameOrPwdException{
		
	}

}
