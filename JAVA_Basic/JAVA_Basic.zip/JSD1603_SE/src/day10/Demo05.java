package day10;

public class Demo05 {

	public static void main(String[] args) {
		IOUtils.cp("dema.txt", "abc.txt"); 
		System.out.println("复制成功");
	}

}
