package day01;
/**
 * int length()
 * 该方法用来获取当前字符串长度
 * @author Administrator
 *
 */
public class StringDemo1 {
	public static void main(String[] args) {
		String str = "你好java";
		System.out.println(str.length());
	}
}
