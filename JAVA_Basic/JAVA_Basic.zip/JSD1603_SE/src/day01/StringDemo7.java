package day01;
/**
 * 字符串提供了可以将字符串中英文转换为
 * 全大写或全小写的方法
 * String toUpperCase()
 * String toLowerCase()
 * @author Administrator
 *
 */
public class StringDemo7 {
	public static void main(String[] args) {
		String str = "我爱Java";
		String upper = str.toUpperCase();
		System.out.println(upper);
		
		String lower = str.toLowerCase();
		System.out.println(lower);
	}
}






