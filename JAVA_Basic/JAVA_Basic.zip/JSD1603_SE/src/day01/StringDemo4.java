package day01;
/**
 * String trim()
 * 去除字符串的头尾空格
 * @author Administrator
 *
 */
public class StringDemo4 {
	public static void main(String[] args) {
		String str = "  hello		";
		String trim = str.trim();
		System.out.println(str);
		System.out.println(trim);
	}
}
