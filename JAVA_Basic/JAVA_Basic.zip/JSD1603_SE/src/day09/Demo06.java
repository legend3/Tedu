package day09;

import java.io.PrintWriter;

public class Demo06 {

	public static void main(String[] args) {
		 
	}

}
