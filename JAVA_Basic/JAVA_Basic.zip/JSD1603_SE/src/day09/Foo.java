package day09;

import java.io.Serializable;
/*
 * 对象流要求 被序列化的对象实现Serializable
 * 接口！Java编译器在编译实现Serializable接口
 * 对象时候会自动的插入3个方法！这些方法将被
 * 对象流调用，用于对象序列化。
 */
public class Foo implements Serializable {
	
	/**
	 * 序列化版本号，实现Serializable时候
	 * 建议添加的属性。要保持稳定，可以避免
	 * 序列化时候遇到的问题。
	 */
	private static final long 
		serialVersionUID = -43858545680L;
	
	int n;
	transient String s;
	public Foo() {
	}
	public Foo(int n, String s) {
		this.n = n;
		this.s = s;
	}
	public String toString() {
		return "Foo [n=" + n + ", s=" + s + "]";
	}
}
