package day05;

public class StringDemo {
	public static void main(String[] args) {
		/*
		 * 1100001 -> 10进制 ->97
		 * 1100001 -> 字符     ->a
		 * 1100001 -> 8进制  ->141
		 */
		
		String str = "\10\4";
		System.out.println(str);
		
	}
}
