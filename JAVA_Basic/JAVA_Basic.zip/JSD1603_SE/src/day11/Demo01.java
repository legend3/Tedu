package day11;

public class Demo01 {
	public static void main(String[] args) {
		//创建Runnable接口的子类对象
		MyRunner runner = new MyRunner();
		//创建线程对象，以Runnable子类对象作为参数
		Thread t = new Thread(runner);
		//使用start启动线程。
		t.start();
	}
}

class MyRunner implements Runnable{
	public void run() {
		System.out.println("Hello World!");
	}
}
 
