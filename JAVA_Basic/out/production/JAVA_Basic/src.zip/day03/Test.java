package day03;

public class Test {
	public static void main(String[] args) {
		long max = Long.MAX_VALUE;
		long year = max/1000/60/60/24/365;
		System.out.println(1970+year);
	}
}
