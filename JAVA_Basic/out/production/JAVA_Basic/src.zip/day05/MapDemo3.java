//package day05;
//
//import java.util.HashMap;
//import java.util.Map;
//
//public class MapDemo3 {
//    public static void main(String[] args) {
//        Map<Key, String> map = new HashMap<Key, String>();
//        map.put(new Key(34,177), "小明");
//        map.put(new Key(17,175), "刘欢");
//        System.out.println(map);
//    }
//
//}
